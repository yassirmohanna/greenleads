import fs from "fs";
import path from "path";
import { prisma } from "./client";

export type KeywordConfig = {
  landscaping: { strong: string[]; weak: string[] };
  install: { strong: string[]; weak: string[] };
  negative: string[];
};

export type AppSettings = {
  keywordConfig: KeywordConfig;
  cityList: string[];
  threshold: number;
  pollIntervalMinutes: number;
  rateLimitPerHour: number;
  storeRawEmail: boolean;
  smsTargets: string[];
  emailTargets: string[];
  lastImapUid?: number | null;
  lastGmailQueryAfter?: number | null;
};

const DEFAULT_SETTINGS_PATH = path.join(
  process.cwd(),
  "config",
  "default-settings.json"
);

const parseEnvList = (value?: string): string[] =>
  value
    ? value
        .split(/[\n,]/)
        .map((item) => item.trim())
        .filter(Boolean)
    : [];

const loadDefaultSettings = (): Omit<AppSettings, "smsTargets" | "emailTargets"> & {
  smsTargets?: string[];
  emailTargets?: string[];
} => {
  const raw = fs.readFileSync(DEFAULT_SETTINGS_PATH, "utf8");
  return JSON.parse(raw);
};

export const getSettings = async (): Promise<AppSettings> => {
  const existing = await prisma.settings.findUnique({ where: { id: 1 } });
  if (existing) {
    return {
      keywordConfig: existing.keywordConfig as KeywordConfig,
      cityList: existing.cityList as string[],
      threshold: existing.threshold,
      pollIntervalMinutes: existing.pollIntervalMinutes,
      rateLimitPerHour: existing.rateLimitPerHour,
      storeRawEmail: existing.storeRawEmail,
      smsTargets: existing.smsTargets as string[],
      emailTargets: existing.emailTargets as string[],
      lastImapUid: existing.lastImapUid,
      lastGmailQueryAfter: existing.lastGmailQueryAfter
    };
  }

  const defaults = loadDefaultSettings();
  const envSms = parseEnvList(process.env.SMS_TO_NUMBERS);
  const envEmail = parseEnvList(process.env.EMAIL_TO);

  const settings = await prisma.settings.create({
    data: {
      id: 1,
      keywordConfig: defaults.keywords,
      cityList: defaults.cities,
      threshold: defaults.threshold,
      pollIntervalMinutes: defaults.pollIntervalMinutes,
      rateLimitPerHour: defaults.rateLimitPerHour,
      storeRawEmail: defaults.storeRawEmail ?? false,
      smsTargets: envSms.length ? envSms : defaults.smsTargets ?? [],
      emailTargets: envEmail.length ? envEmail : defaults.emailTargets ?? []
    }
  });

  return {
    keywordConfig: settings.keywordConfig as KeywordConfig,
    cityList: settings.cityList as string[],
    threshold: settings.threshold,
    pollIntervalMinutes: settings.pollIntervalMinutes,
    rateLimitPerHour: settings.rateLimitPerHour,
    storeRawEmail: settings.storeRawEmail,
    smsTargets: settings.smsTargets as string[],
    emailTargets: settings.emailTargets as string[],
    lastImapUid: settings.lastImapUid,
    lastGmailQueryAfter: settings.lastGmailQueryAfter
  };
};

export const updateSettings = async (input: Partial<AppSettings>) => {
  return prisma.settings.update({
    where: { id: 1 },
    data: {
      keywordConfig: input.keywordConfig,
      cityList: input.cityList,
      threshold: input.threshold,
      pollIntervalMinutes: input.pollIntervalMinutes,
      rateLimitPerHour: input.rateLimitPerHour,
      storeRawEmail: input.storeRawEmail,
      smsTargets: input.smsTargets,
      emailTargets: input.emailTargets,
      lastImapUid: input.lastImapUid,
      lastGmailQueryAfter: input.lastGmailQueryAfter
    }
  });
};
